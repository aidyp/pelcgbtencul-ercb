rm *.key *.csr *.srl *.cert *.crt *.pem index* 
rm -r serials
